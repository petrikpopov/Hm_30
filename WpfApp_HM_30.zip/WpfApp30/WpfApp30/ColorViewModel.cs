﻿using System;
using System.Collections.ObjectModel;
using System.Windows.Media;
using System.Windows.Input;
using WpfApp30;

namespace WpfApp30
{


    public class ColorViewModel : ViewModelBase
    {
        private byte alpha;
        private byte red;
        private byte green;
        private byte blue;
        private Color selectedColor;

        public ColorViewModel()
        {
            AddColorCommand = new RelayCommand(AddColor, CanAddColor);
            SavedColors = new ObservableCollection<Color>();
        }

        public byte Alpha
        {
            get { return alpha; }
            set
            {
                alpha = value;
                OnPropertyChanged(nameof(Alpha));
                UpdateSelectedColor();
            }
        }

        public byte Red
        {
            get { return red; }
            set
            {
                red = value;
                OnPropertyChanged(nameof(Red));
                UpdateSelectedColor();
            }
        }

        public byte Green
        {
            get { return green; }
            set
            {
                green = value;
                OnPropertyChanged(nameof(Green));
                UpdateSelectedColor();
            }
        }

        public byte Blue
        {
            get { return blue; }
            set
            {
                blue = value;
                OnPropertyChanged(nameof(Blue));
                UpdateSelectedColor();
            }
        }

        public Color SelectedColor
        {
            get { return selectedColor; }
            set
            {
                selectedColor = value;
                OnPropertyChanged(nameof(SelectedColor));
            }
        }

        public ObservableCollection<Color> SavedColors { get; }

        public RelayCommand AddColorCommand { get; }

        private void UpdateSelectedColor()
        {
            SelectedColor = Color.FromArgb(Alpha, Red, Green, Blue);
        }

        private bool CanAddColor(object parameter)
        {
            return !SavedColors.Contains(SelectedColor);
        }

        private void AddColor(object parameter)
        {
            if (!SavedColors.Contains(SelectedColor))
            {
                SavedColors.Add(SelectedColor);
            }
        }
    }
}